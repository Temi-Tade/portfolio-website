import{l as o,a as r}from"../chunks/DrIZ9Zsx.js";export{o as load_css,r as start};
