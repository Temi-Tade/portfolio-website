import{b as o,E as f,a as i,d as p,h as c,c as d,n as h}from"./B3EZPR1m.js";function _(s,e,...t){var r=s,n=h,a;o(()=>{n!==(n=e())&&(a&&(p(a),a=null),a=i(()=>n(r,...t)))},f),c&&(r=d)}export{_ as s};
